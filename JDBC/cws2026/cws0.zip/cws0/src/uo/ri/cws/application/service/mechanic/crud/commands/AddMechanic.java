package uo.ri.cws.application.service.mechanic.crud.commands;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.UUID;

import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.util.assertion.ArgumentChecks;
import uo.ri.util.exception.BusinessException;
import uo.ri.util.jdbc.Jdbc;

public class AddMechanic {

	private static final String TMECHANICS_ADD = "insert into TMechanics"
			+ "(id, nif, name, surname, version, "
			+ "createdAt, updatedAt, entityState) "
			+ "values (?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String CHECK_NIF = "select id from TMechanics where nif = ?";

	private MechanicDto dto;

	public AddMechanic(MechanicDto dto) {
		ArgumentChecks.isNotNull(dto, "Los datos del mecánico no pueden ser nulos");
		ArgumentChecks.isNotBlank(dto.nif, "El NIF no puede estar vacío");
		ArgumentChecks.isNotBlank(dto.name, "El nombre no puede estar vacío");
		ArgumentChecks.isNotBlank(dto.surname, "El apellido no puede estar vacío");
		this.dto = dto;
	}

	public MechanicDto execute() throws BusinessException {

		try (Connection c = Jdbc.createThreadConnection()) {

			checkNifAlreadyExists(c, dto.nif);

			MechanicDto added = new MechanicDto();
			added.id = UUID.randomUUID().toString();
			added.version = 1L;
			added.nif = dto.nif;
			added.name = dto.name;
			added.surname = dto.surname;

			insert(c, added);
			return added;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	private void insert(Connection c, MechanicDto m) throws SQLException {
		Timestamp now = new Timestamp(System.currentTimeMillis());

		try (PreparedStatement pst = c.prepareStatement(TMECHANICS_ADD)) {
			pst.setString(1, m.id);
			pst.setString(2, m.nif);
			pst.setString(3, m.name);
			pst.setString(4, m.surname);
			pst.setLong(5, m.version);
			pst.setTimestamp(6, now);
			pst.setTimestamp(7, now);
			pst.setString(8, "ENABLED");
			pst.executeUpdate();
		}
	}

	private void checkNifAlreadyExists(Connection c, String nif)
			throws SQLException, BusinessException {

		try (PreparedStatement pst = c.prepareStatement(CHECK_NIF)) {
			pst.setString(1, nif);
			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next()) {
					throw new BusinessException("Ya existe el nif " + nif);
				}
			}
		}
	}
}