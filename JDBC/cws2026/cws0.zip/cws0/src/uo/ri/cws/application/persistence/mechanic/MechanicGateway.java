package uo.ri.cws.application.persistence.mechanic;

public class MechanicGateway {

}
